$(function () {
    var $container = $('#gallery'),
        $loadMoreBtn = $('#load-more'),
        $addItemCount = 10,//한번에 표시할 항목의 개수
        $added = 0,  //표시된 항목의 개수
        $allData = []; //모든 json data를 담을 그릇

    //$.getJSON('./data/content.json', function(data)(){  });    
    $.getJSON('./data/content.json', initGallery);

    function initGallery(data){
        //모든 리스트를 alldata 저장
        $allData = data;    
        
        //첫번째 10개 표시
        addItems();

        $loadMoreBtn.click(addItems);
    }//initGallery

    function addItems(){
        var elements = [],  
            slicedData = $allData.slice($added, $added + $addItemCount);

        $.each(slicedData, function(i, item){
            var itemHtml = 
            '<li class="gallery-item">' + item.title + '</li>';
            elements.push($(itemHtml).get(0));
            $container.append(elements);
        });//slicedData item 마다 할일

        $added += $addItemCount;

        if($added < $allData.length){
            $loadMoreBtn.show();
        }else{
            $loadMoreBtn.hide();
        }

    }//addItems

});//document ready
