$(function(){

  $('.slider').slick();

  $('.control').slick();

  $('.control2').slick({
    prevArrow:'.control-slide2 .prev',
    nextArrow:'.control-slide2 .next',
  });

  let control3 = $('.control3').slick({
    arrows:false
  });

  $('.control-slide3 .prev').click(function(){
    control3.slick('slickPrev');
  });
  $('.control-slide3 .next').click(function(){
    control3.slick('slickNext');
  });

  $('.multiple-slider').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 3
  });

});