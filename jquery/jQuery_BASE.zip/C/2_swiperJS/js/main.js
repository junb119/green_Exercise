$(function(){

	

});//document ready jquery 