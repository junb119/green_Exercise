$(function(){
    


});//document ready 할일