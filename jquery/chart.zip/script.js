let sun = new Image();
sun.src = 'https://assets.codepen.io/485050/sun.png';

let snow = new Image();
snow.src = 'https://assets.codepen.io/485050/snow.png';

const lineChart = document.getElementById('line-chart');

const barChart = document.getElementById('bar-chart');

new Chart(lineChart, {
  type: 'line',
  data: {
    labels: ['1월', '2월', '3월', '4월', '5월', '6월'],
    datasets: [
        {
        label: '2023',
        data: [12, 19, 3, 5, 2, 3],
        borderWidth: 1
        },
        {
          label: '2024',
          data: [4, 12, null, 7, 10, 5],
          borderWidth: 2,
          // hoverBorderWidth:5,
          // borderColor: 'rgba(0,0,0,0.5)',
          // backgroundColor:'yellow',
          // radius:4,
          // hoverRadius:10,
          // pointBorderColor:'black',
          // pointStyle:sun,
          // showLine:true,
          spanGaps:true,
          // stepped:true
        }
    ]
  },
  options: {
    scales: {
      y: {
        // beginAtZero: true
        stacked:true
      }
    },
    maintainAspectRatio:false
  }
});
const mydata = {
  labels: ['1월', '2월', '3월', '4월', '5월', '6월'],
  datasets: [
      {
        label: '2024',
        data: [4, 12, 8, 7, 10, 5],
        borderWidth: 2   
      }
  ]
}
new Chart(barChart, {
  type: 'bar',
  data: mydata,
  options: {
    scales: {
      y: {
        // beginAtZero: true
        // stacked:true
      }
    },
    maintainAspectRatio:false
  }
});