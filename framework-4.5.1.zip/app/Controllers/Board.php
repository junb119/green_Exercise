<?php

namespace App\Controllers;

class Board extends BaseController
{
    public function list(): string
    {
        return view('board_list');
    }
    public function write()
    {
        return view('board_write');
    }
}
