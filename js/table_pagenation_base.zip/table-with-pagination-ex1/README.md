# Table with pagination ex1

A Pen created on CodePen.io. Original URL: [https://codepen.io/alikerock/pen/zQypjq](https://codepen.io/alikerock/pen/zQypjq).

